
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import MainLayout from './components/layout/MainLayout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import VerifyCode from './pages/VerifyCode';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import CheckoutSuccess from './pages/CheckoutSuccess';
import CheckoutFailed from './pages/CheckoutFailed';
import PaymentReturn from './pages/PaymentReturn';
import ProfileLayout from './pages/profile/ProfileLayout';
import ProfileInfo from './pages/profile/ProfileInfo';
import ProfileOrders from './pages/profile/ProfileOrders';
import ProfileFavorites from './pages/profile/ProfileFavorites';
import ProfileAddresses from './pages/profile/ProfileAddresses';
import ProfileChangePassword from './pages/profile/ProfileChangePassword';
import ProfileLoyalty from './pages/profile/ProfileLoyalty';
import ProductDetail from './pages/ProductDetail';

function App() {
  return (
    <BrowserRouter>
      {/* React Toastify for global notifications */}
      <ToastContainer
        position="top-center"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />

      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="verify" element={<VerifyCode />} />
          <Route path="cart" element={<Cart />} />
          <Route path="checkout" element={<Checkout />} />
          <Route path="product/:id" element={<ProductDetail />} />
          <Route path="checkout/success" element={<CheckoutSuccess />} />
          <Route path="checkout/failed" element={<CheckoutFailed />} />
          <Route path="payment/return" element={<PaymentReturn />} />

          {/* Profile Routes */}
          <Route path="profile" element={<ProfileLayout />}>
            <Route index element={<ProfileInfo />} />
            <Route path="orders" element={<ProfileOrders />} />
            <Route path="favorites" element={<ProfileFavorites />} />
            <Route path="addresses" element={<ProfileAddresses />} />
            <Route path="change-password" element={<ProfileChangePassword />} />
            <Route path="loyalty" element={<ProfileLoyalty />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
