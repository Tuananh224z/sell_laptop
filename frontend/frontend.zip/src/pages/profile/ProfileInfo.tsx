import { useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';

const ProfileInfo = () => {
  const [profile, setProfile] = useState({
    name: 'Nguyễn Văn A',
    email: 'nguyenvana@example.com',
    phone: '0912345678',
    gender: 'male',
    dob: '1995-05-15',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // mock save profile
    console.log('Saved Profile:', profile);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8">
      <div className="mb-6 pb-4 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-900">Hồ sơ của tôi</h2>
        <p className="text-sm text-gray-500 mt-1">Quản lý thông tin hồ sơ để bảo mật tài khoản</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        
        {/* Form */}
        <div className="lg:w-2/3">
          <form className="space-y-6" onSubmit={handleSubmit}>
            
            <div className="grid grid-cols-3 items-center gap-4">
              <label className="col-span-1 text-sm font-medium text-gray-700 text-right pr-4">Họ và tên</label>
              <div className="col-span-2">
                <input 
                  type="text" 
                  value={profile.name}
                  onChange={(e) => setProfile({...profile, name: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:ring-1 focus:ring-primary-500 focus:border-primary-500" 
                />
              </div>
            </div>

            <div className="grid grid-cols-3 items-center gap-4">
              <label className="col-span-1 text-sm font-medium text-gray-700 text-right pr-4">Email</label>
              <div className="col-span-2 flex items-center gap-2">
                <span className="text-sm font-medium text-gray-900">{profile.email}</span>
                <button type="button" className="text-sm text-primary-600 font-medium hover:underline">Thay đổi</button>
              </div>
            </div>

            <div className="grid grid-cols-3 items-center gap-4">
              <label className="col-span-1 text-sm font-medium text-gray-700 text-right pr-4">Số điện thoại</label>
               <div className="col-span-2 flex items-center gap-2">
                <span className="text-sm font-medium text-gray-900">{profile.phone}</span>
                <button type="button" className="text-sm text-primary-600 font-medium hover:underline">Thay đổi</button>
              </div>
            </div>

            <div className="grid grid-cols-3 items-center gap-4">
              <label className="col-span-1 text-sm font-medium text-gray-700 text-right pr-4">Giới tính</label>
              <div className="col-span-2 flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="gender" value="male" checked={profile.gender === 'male'} onChange={(e) => setProfile({...profile, gender: e.target.value})} className="text-primary-600 focus:ring-primary-500" />
                  <span className="text-sm text-gray-700">Nam</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="gender" value="female" checked={profile.gender === 'female'} onChange={(e) => setProfile({...profile, gender: e.target.value})} className="text-primary-600 focus:ring-primary-500" />
                  <span className="text-sm text-gray-700">Nữ</span>
                </label>
                 <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="gender" value="other" checked={profile.gender === 'other'} onChange={(e) => setProfile({...profile, gender: e.target.value})} className="text-primary-600 focus:ring-primary-500" />
                  <span className="text-sm text-gray-700">Khác</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-3 items-center gap-4">
              <label className="col-span-1 text-sm font-medium text-gray-700 text-right pr-4">Ngày sinh</label>
              <div className="col-span-2">
                <input 
                  type="date" 
                  value={profile.dob}
                  onChange={(e) => setProfile({...profile, dob: e.target.value})}
                  className="w-full max-w-[200px] border border-gray-300 rounded-lg p-2.5 text-sm focus:ring-1 focus:ring-primary-500 focus:border-primary-500 text-gray-700" 
                />
              </div>
            </div>

            <div className="grid grid-cols-3 items-center gap-4 pt-4">
              <div className="col-span-1"></div>
              <div className="col-span-2">
                <button type="submit" className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-2.5 px-8 rounded-lg shadow-sm transition-colors">
                  Lưu thay đổi
                </button>
              </div>
            </div>
            
          </form>

          {/* Default Address Section */}
          <div className="mt-8 pt-6 border-t border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-800">Địa chỉ giao hàng mặc định</h3>
              <Link to="/profile/addresses" className="text-xs text-primary-600 font-medium hover:underline">Quản lý địa chỉ</Link>
            </div>
            <div className="flex items-start gap-3 bg-gray-50 border border-gray-200 rounded-xl p-4">
              <MapPin className="w-5 h-5 text-primary-600 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-sm text-gray-900">Nguyễn Văn A</span>
                  <span className="text-gray-400 text-xs">|</span>
                  <span className="text-sm text-gray-600">0912 345 678</span>
                  <span className="text-xs font-semibold text-primary-600 border border-primary-300 bg-primary-50 px-2 py-0.5 rounded">Mặc định</span>
                </div>
                <p className="text-sm text-gray-600">123 Đường Công Nghệ, Phường 1, Quận 1</p>
                <p className="text-sm text-gray-600">TP. Hồ Chí Minh</p>
              </div>
            </div>
          </div>
        </div>

        {/* Avatar Area */}
         <div className="lg:w-1/3 flex flex-col items-center justify-start border-l border-gray-100 pl-10 border-t lg:border-t-0 pt-8 lg:pt-0">
            <div className="w-28 h-28 bg-primary-50 rounded-full border-2 border-gray-200 flex items-center justify-center mb-4 overflow-hidden">
               <span className="text-4xl text-primary-400 font-bold uppercase">NA</span>
            </div>
            <button className="bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 font-medium py-2 px-6 rounded-lg shadow-sm transition-colors text-sm">
              Chọn Ảnh
            </button>
            <p className="text-xs text-gray-400 mt-4 text-center">
              Dụng lượng file tối đa 1 MB <br/>
              Định dạng: .JPEG, .PNG
            </p>
         </div>

      </div>
    </div>
  );
};

export default ProfileInfo;
