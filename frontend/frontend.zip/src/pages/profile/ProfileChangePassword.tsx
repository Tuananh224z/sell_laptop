import { useState } from 'react';
import { Lock, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { toast } from 'react-toastify';

const ProfileChangePassword = () => {
  const [form, setForm] = useState({ current: '', newPass: '', confirm: '' });
  const [show, setShow] = useState({ current: false, newPass: false, confirm: false });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.newPass !== form.confirm) {
      toast.error('Mật khẩu mới không khớp!');
      return;
    }
    if (form.newPass.length < 8) {
      toast.error('Mật khẩu mới phải có ít nhất 8 ký tự!');
      return;
    }
    toast.success('Đổi mật khẩu thành công!');
    setForm({ current: '', newPass: '', confirm: '' });
  };

  const PasswordField = ({
    label, field, value
  }: {
    label: string;
    field: 'current' | 'newPass' | 'confirm';
    value: string;
  }) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Lock className="h-4 w-4 text-gray-400" />
        </div>
        <input
          type={show[field] ? 'text' : 'password'}
          required
          value={value}
          onChange={e => setForm({ ...form, [field]: e.target.value })}
          placeholder="••••••••"
          className="block w-full pl-10 pr-10 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-1 focus:ring-primary-500 focus:border-primary-500 bg-gray-50 focus:bg-white transition-colors"
        />
        <button
          type="button"
          onClick={() => setShow({ ...show, [field]: !show[field] })}
          className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
        >
          {show[field] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8">
      <div className="mb-6 pb-4 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-900">Đổi mật khẩu</h2>
        <p className="text-sm text-gray-500 mt-1">Đảm bảo tài khoản của bạn luôn được bảo mật</p>
      </div>

      <div className="max-w-md">
        <form onSubmit={handleSubmit} className="space-y-5">
          <PasswordField label="Mật khẩu hiện tại" field="current" value={form.current} />
          <PasswordField label="Mật khẩu mới" field="newPass" value={form.newPass} />
          <PasswordField label="Xác nhận mật khẩu mới" field="confirm" value={form.confirm} />

          {/* Password strength hints */}
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 space-y-2">
            <p className="text-xs font-semibold text-blue-700 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> Yêu cầu mật khẩu mạnh
            </p>
            <ul className="space-y-1">
              {[
                'Ít nhất 8 ký tự',
                'Bao gồm chữ hoa và chữ thường',
                'Bao gồm ít nhất 1 số',
                'Không trùng với mật khẩu cũ',
              ].map(hint => (
                <li key={hint} className="text-xs text-blue-600 flex items-center gap-1.5">
                  <span className="w-1 h-1 rounded-full bg-blue-400 inline-block shrink-0" />
                  {hint}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-2.5 px-8 rounded-lg shadow-sm transition-colors"
            >
              Xác nhận đổi mật khẩu
            </button>
            <button
              type="button"
              onClick={() => setForm({ current: '', newPass: '', confirm: '' })}
              className="border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-2.5 px-6 rounded-lg transition-colors"
            >
              Hủy
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfileChangePassword;
